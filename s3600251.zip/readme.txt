/***********************************************************************
 * COSC1076 - Advanced Programming Techniques
 * Semester 2 2016 Assignment #1 
 * Full Name        : Neil D'Souza
 * Student Number   : s3600251
 * Course Code      : EDIT HERE
 * Program Code     : EDIT HERE
 * Start up code provided by Paul Miller 
 **********************************************************************/

 This file is for you to provide any extra information that your
 markers may find useful. For example. Bugs, inconsistencies, incomplete
 functionality, reasoning for design choices etc.


- Removed enum cell dir seeing as it was optional.

- Wasn't sure about making a function for input validation and error handling 
  seeing as in almost every case it was used and handled differently.

- Indentation was inconsistent between putty and text editor
  I tried to keep all indentation 3 spaces wide. (4 from first column).
